public class HappyNewYear {
    public static void main(String[] args) throws InterruptedException {
        System.out.println("Counting down to the New Year...");
        for (int i = 10; i > 0; i--) {
            System.out.println(i);
            Thread.sleep(1000); // Pause for 1 second
        }
        System.out.println("Happy New Year 2025!");
    }
}
